import { Component } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  constructor(
    private cartService: CartService
  ) { 
    document.body.style.background = "linear-gradient(#141e30, #243b55)";
    document.body.style.height = "100vh";
  }

  items = this.cartService.getItems();

}